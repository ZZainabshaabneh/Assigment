function validateEmail() {
  const email = document.getElementById('email').value;
  const emailError = document.getElementById('error');
 email.textContent = email.value.includes('@')

  if ( email.textContent) {
      emailError.innerHTML = "Valid email.";
      emailError.style.color = "green";
    
  } else {
    emailError.innerHTML = "Invalid email format!";
  }
}
const element = document.getElementById("tog");
element.addEventListener("click", myFunction);

function myFunction() {
    document.getElementById("prev").style.display;
}




document.getElementById('theme-btn').addEventListener('click', mod)

function mod() {
    const list = document.getElementById("them").classList;
    list.toggle("dark-mode"); 
 
}